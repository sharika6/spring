package demo.repo;

import demo.beans.Customer;

public interface WalletRepository {

	boolean save(Customer c);
	Customer findOne(String mobileNumber);
	
}
