package demo.repo;

import demo.beans.Customer;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

//@org.springframework.stereotype.Repository
public class Repository implements WalletRepository {
    //@Resource(name="map")
	private Map<String,Customer> map;
   
   public Repository(Map<String, Customer> map)
	{
		this.map = map;
	}
	public boolean save(Customer c) {
		map.put(c.getMobileNumber(), c);
		return true;
	}

	public Customer findOne(String mobileNumber) {
		Customer c = map.get(mobileNumber);
		return c;
	}

}