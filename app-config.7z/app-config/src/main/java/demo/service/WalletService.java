package demo.service;

import demo.beans.Customer;

public interface WalletService {

 Customer createAccount(String name,String mobileNumber,float amount );
 Customer showBalance(String mobileNumber);
 boolean withdraw(float amount,String mobileNumber);
 boolean deposit(float amount,String mobileNumber);
}
