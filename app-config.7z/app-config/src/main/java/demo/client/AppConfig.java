package demo.client;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import demo.beans.Customer;
import demo.service.Service;
import demo.repo.Repository;
@Configuration
@ComponentScan(basePackages="demo")
public class AppConfig {

	@Bean(value="map")
	public Map<String,Customer> getMap(){
		return new HashMap<String,Customer>();
	}
	@Bean(value="repo")
	public  Repository getRepo(){
		return new Repository(getMap());
	}
	@Bean(value="service")
	public Service getService() {
		return new Service(getRepo());
	}
}
