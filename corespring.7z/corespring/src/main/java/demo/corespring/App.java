package demo.corespring;

import org.springframework.context.support.GenericXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
    	//MessageService ms=new MessageService();
    	//ms.printMessage();
    	GenericXmlApplicationContext ctx =new GenericXmlApplicationContext("demo/corespring/beanconfig.xml");
    	MessageService service1=ctx.getBean("msg", MessageService.class);
    	
    	//System.out.println(service1==service2) ;
    	service1.printMessage();
    	
    }
}

