package demo.repo;

import demo.beans.Customer;

import java.util.HashMap;
import java.util.Map;
public class Repository implements WalletRepository {
   Map<String,Customer> map;
   public Repository(Map<String, Customer> map)
	{
		this.map = map;
	}
	public boolean save(Customer c) {
		map.put(c.getMobileNumber(), c);
		return true;
	}

	public Customer findOne(String mobileNumber) {
		Customer c = map.get(mobileNumber);
		return c;
	}

}