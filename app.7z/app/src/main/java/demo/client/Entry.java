package demo.client;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.support.GenericXmlApplicationContext;

import demo.beans.Customer;
import demo.beans.Wallet;
import demo.service.Service;
import demo.service.WalletService;

public class Entry {
public static void main(String[] args) {
	GenericXmlApplicationContext ctx=new GenericXmlApplicationContext("beanconfig.xml");
	Service s=ctx.getBean("service", demo.service.Service.class);
	Customer c1=s.createAccount("sharika", "9000351816",10000f);
	Customer c2=s.createAccount("sahir", "9090909090", 10000f);
	Customer c3=s.createAccount("madhav", "9000090000",10000f);
	Customer c4=s.createAccount("sahir", "9595959595", 10000f);
	
	System.out.println(c1);
	System.out.println(c2);
	System.out.println(c3);
	System.out.println(c4);
	
	System.out.println("After deposit--------------------");
	System.out.println(s.deposit(1000f, "9090909090"));
	System.out.println(s.showBalance("9090909090"));
	
	System.out.println("After withdraw--------------------");
	System.out.println(s.withdraw(1000f, "9000351816"));
	System.out.println(s.showBalance("9000351816"));
	
	
}
}
