package demo.service;

import demo.beans.Customer;
import demo.beans.Wallet;
import demo.repo.Repository;
import demo.repo.WalletRepository;

public class Service implements WalletService {
	WalletRepository repo;
	public Service(WalletRepository wr) {
		this.repo=wr;
	}
	public boolean deposit(float amount,String mobileNumber){
		Customer c=repo.findOne(mobileNumber);
		Wallet w=c.getWallet();
		float balance=c.getWallet().getBalance()+amount;
		w.setBalance(balance);
		c.setWallet(w);
		repo.save(c);
		return true;
	}
	public  boolean withdraw(float amount,String mobileNumber){
		Customer c=repo.findOne(mobileNumber);
		Wallet w=c.getWallet();
		if(amount > c.getWallet().getBalance()){
			return false;
		}
		else 
	    w=c.getWallet();
	    float balance =w.getBalance()-amount;
		w.setBalance(balance);
		c.setWallet(w);
		repo.save(c);
		return true; 
	}

	
	public Customer showBalance(String mobileNumber) {
		return repo.findOne(mobileNumber);
	}


	public Customer createAccount(String name, String mobileNumber, float amount) {
		Customer c = new Customer();
		Wallet w  = new Wallet();
		c.setName(name);
		c.setMobileNumber(mobileNumber);
		w.setBalance(amount);
		c.setWallet(w);
		
		repo.save(c);
		return c;
	}
	
}

