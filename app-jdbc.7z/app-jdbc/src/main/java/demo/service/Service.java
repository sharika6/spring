package demo.service;
import demo.beans.Customer;
import demo.beans.Wallet;
import demo.repo.WalletRepository;


public class Service implements WalletService {


	private WalletRepository repo;
	public Service(WalletRepository repo) {
		this.repo = repo;
	}

	
	public Customer createAccount(String name, String mobileNumber, float amount) {
		Wallet w = new Wallet(amount);
		Customer c = new Customer(name, mobileNumber, w);
		repo.save(c);
		return c;
	}

	
	public Customer showBalance(String mobileNumber) {
		Customer c = repo.findOne(mobileNumber);
		return c;
	}

	@Override
	public boolean withdraw(float amount, String mobileNumber) {
		
		Customer c=repo.findOne(mobileNumber);
		Wallet w=c.getWallet();
		if(amount > c.getWallet().getBalance()){
			return false;
		}
		else 
	    w=c.getWallet();
	    float balance =w.getBalance()-amount;
		w.setBalance(balance);
		c.setWallet(w);
		repo.save(c);
		return true; 
	}


	@Override
	public boolean deposit(float amount, String mobileNumber) {
		Customer c=repo.findOne(mobileNumber);
		Wallet w=c.getWallet();
		float balance=c.getWallet().getBalance()+amount;
		w.setBalance(balance);
		c.setWallet(w);
		repo.save(c);
		return true;
	}

}
