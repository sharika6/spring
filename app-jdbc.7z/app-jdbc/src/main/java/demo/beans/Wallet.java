package demo.beans;

public class Wallet {
	public Wallet(float balance) {
		this.balance = balance;
	}

float balance;

public float getBalance() {
	return balance;
}

public void setBalance(float balance) {
	this.balance = balance;
}
  
}
