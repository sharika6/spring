package demo.client;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import demo.beans.Customer;
import demo.service.Service;
import demo.repo.Repository;
import demo.repo.WalletRepository;
@Configuration
@ComponentScan(basePackages="demo")
public class AppConfig {

	WalletRepository repo;
	@Bean(value="repo")
	public Repository getRepo()
	{
		repo= new Repository();
		return (Repository) repo;
	}
	@Bean(value="service")
	public Service getService() {
		return new Service(getRepo());
	}
}
