package demo.client;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import demo.service.*;
import demo.beans.Customer;
import demo.repo.*;
public class Entry {
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/test";
	   //static final String JDBC_DRIVER = "org.h2.Driver";  
	   //static final String DB_URL = "jdbc:h2:~/test1";
	   static String USER = "";
	   static String PASS = "";
	   public static void main(String[] args) throws SQLException {
		   
	   Connection conn = null;
	   java.sql.Statement stmt = null;
	   
			   
	   try{
	      
	      Class.forName(JDBC_DRIVER);

	      
	      System.out.println("Connecting to a selected database...");
	      conn = DriverManager.getConnection(DB_URL,USER,PASS);
	      System.out.println("Connected database successfully...");
	      
	      
	      System.out.println("Creating table in given database...");
	      stmt = conn.createStatement();
	      String sqlw= "CREATE TABLE WALLET " +
	              "(id INTEGER not NULL PRIMARY KEY, " +
	              " balance DECIMAl(8,2)) ";  
			stmt.executeUpdate(sqlw); 
			System.out.println("Created wallet table in given database...");                             
	      String sqlc= "CREATE TABLE CUSTOMER " +
	              "(id INTEGER not NULL, " +
	              " name VARCHAR(20), " + 
	              " mobile_number INTEGER(20), " +
	              "wallet_id INTEGER not null," +
	              "primary key(id), " +
	              "foreign key(wallet_id) references WALLET(id))";
	      stmt.executeUpdate(sqlc);
	      System.out.println("Created customer table in given database...");
	  	
			//stmt.close();
			//conn.close();
			 
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			stmt.close();
			conn.close();
			System.out.println("Goodbye!");
		}
	   
	}
	    
	}
	
