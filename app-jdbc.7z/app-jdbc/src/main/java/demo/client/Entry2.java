package demo.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import demo.beans.Customer;
import demo.service.Service;

public class Entry2 {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext(AppConfig.class);
		
		//GenericXmlApplicationContext ctx=new GenericXmlApplicationContext("beanconfig.xml");
		Service s=ctx.getBean("service", demo.service.Service.class);
		Customer c1=s.createAccount("sharika", "900035186",10000f);
		Customer c2=s.createAccount("sahir", "909090900", 10000f);
		Customer c3=s.createAccount("madhav", "900009000",10000f);
		Customer c4=s.createAccount("sahir", "959595995", 10000f);
		
		/*System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);
		System.out.println(c4);*/
		
		System.out.println("After deposit--------------------");
		System.out.println(s.deposit(100f, "900035186"));
		System.out.println(s.showBalance("900035186"));
		
		System.out.println("After withdraw--------------------");
		System.out.println(s.withdraw(500f, "900035186"));
		System.out.println(s.showBalance("900035186"));
		
		
	}
	}
