package demo.repo;

import demo.beans.Customer;

public interface WalletRepository {

	public boolean save(Customer c);
	public Customer findOne(String mobileNumber);
	public boolean update(String mobileNumber,float updatedBalace);
}
