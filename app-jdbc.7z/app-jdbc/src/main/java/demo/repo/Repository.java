package demo.repo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import demo.beans.Customer;
import demo.beans.Wallet;
import demo.client.Entry;

public class Repository implements WalletRepository
{
	static int i=0;
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
   //static final String JDBC_DRIVER = "org.h2.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/test";
	//static final String DB_URL = "jdbc:h2:~/test1";

	//  Database credentials
	static final String USER = "";
	static final String PASS = "";
	private Connection conn = null;
	private Statement stmt= null;
	private PreparedStatement pstmt =null;
	private ResultSet rs=null;

	@Override
	public boolean save(Customer c) 
	{
		String mobileNumber = c.getMobileNumber();
		String name=c.getName();
		float balance= c.getWallet().getBalance();
		

		try
		{
			i++;
			//STEP 2: Register JDBC driver
			Class.forName(JDBC_DRIVER);

			//STEP 3: Open a connection
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(DB_URL,USER,PASS);
			stmt = conn.createStatement();
			
			System.out.println("database connected");
			
// Using Statement
			/*String sql="insert into wallet values" + "(" + i + "," + balance + ")";			
			stmt.executeUpdate(sql);
			sql = "INSERT INTO customer " +
	                   "VALUES(" + i + ",'" + name + "'," + mobileNumber + "," + i + ")";
			stmt.executeUpdate(sql);*/
			
// Using Prepared Statement
			String sqlw="insert into wallet values("+i+",?)";
			pstmt=conn.prepareStatement(sqlw);
			pstmt.setDouble(1, balance);	
			pstmt.executeUpdate();
	
			String sqlc = "insert into customer values("+i+",?,?,"+i+")";
			pstmt=conn.prepareStatement(sqlc);
			pstmt.setString(1, name);
			pstmt.setString(2, mobileNumber);
			pstmt.executeUpdate(); 
	
			System.out.println("row inserted");
			
			
		}catch(Exception e)
		{
			System.out.println(e);	
		}
		finally {
			try {
				conn.close();
				stmt.close();
			    } catch (SQLException e) {
				e.printStackTrace();
			    }
			
		        }
		
		return true;
		
	}

	@Override
	public Customer findOne(String mobileNumber) 
	{
		Customer c=null;
		try
		{
			//STEP 2: Register JDBC driver
			Class.forName(JDBC_DRIVER);
			
			
			//STEP 3: Open a connection
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(DB_URL,USER,PASS);
			stmt = conn.createStatement();
			System.out.println("connected");
			
// Using Statement
			/*String sql="SELECT customer.name,customer.mobile_number,wallet.balance from customer INNER JOIN wallet ON wallet.id=customer.wallet_id where customer.mobile_number= " + mobileNumber;

			rs=stmt.executeQuery(sql);*/
			
			
// Using PreparedStatement
			String sql="SELECT customer.name,customer.mobile_number,wallet.balance from customer, wallet where wallet.id=customer.wallet_id AND customer.mobile_number=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, mobileNumber);
			rs=pstmt.executeQuery();

			
			while(rs.next())
			{
			   
			         String Name = rs.getString("name");
			         int mobileNumbers = rs.getInt("mobile_number");
			         float balance=rs.getFloat("balance");
			         
			         String mobile_no= mobileNumbers+"";
			         
			         Wallet w = new Wallet(balance);
			         c = new Customer(Name, mobile_no, w);
			}
			
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
		
		
		return c;
		
	}

	public boolean update(String mobileNumber,float updatedBalance)
	{
		Customer c=null;
		try
		{
			//STEP 2: Register JDBC driver
			Class.forName(JDBC_DRIVER);

			//STEP 3: Open a connection
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(DB_URL,USER,PASS);
			stmt = conn.createStatement();
			System.out.println("connected");
			
// Using Statement
			/*String sql="update customer INNER JOIN wallet ON wallet.id=customer.wallet_id SET wallet.balance ="+ updatedBalance + "where customer.mobile_number= " + mobileNumber;

			stmt.executeUpdate(sql);*/


			
// Using PreparedStatement
			String sql="update customer, wallet SET wallet.balance=(?) where where wallet.id=customer.wallet_id AND customer.mobile_number=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setFloat(1, updatedBalance);
			pstmt.setString(2, mobileNumber);
			
			pstmt.executeUpdate();

			System.out.println("updated");
			
			
		}catch(Exception e)
		{
			System.out.println(e);
			
		}
		finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		return true;
		
	}
}
